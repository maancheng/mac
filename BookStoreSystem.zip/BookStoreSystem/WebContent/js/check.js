	function logincheck() {
		if (document.loginForm.username.value == "") {
			alert("用户名不能为空");
			return false;
		}
		if (document.loginForm.password.value == "") {
			alert("密码不能为空");
			return false;
		}
	}